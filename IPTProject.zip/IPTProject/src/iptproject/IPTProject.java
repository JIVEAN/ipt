package iptproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class IPTProject extends JFrame{
    JLabel lblTitle, lblTajuk;
    JButton btnCust, btnStaff, btnClose;
    
    IPTProject(){
        setLayout(null);
        setTitle("MAIN MENU");
        
        lblTitle = new JLabel("::MAIN MENU::");
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 18));
        lblTitle.setBounds(150, 10, 200, 30);
        add(lblTitle);
        
        lblTajuk = new JLabel("IZZAH CAR RENTAL SYSTEM");
        lblTajuk.setForeground(Color.BLUE);
        lblTajuk.setFont(new Font("VERDANA",Font.BOLD, 21));
        getContentPane().setBackground(new Color(236, 220, 252));
        lblTajuk.setBounds(55, 40, 500, 30);
        add(lblTajuk);
        
        btnCust = new JButton ("CUSTOMER");
        btnCust.setBackground(Color.GREEN); // Set background color
        btnCust.setBounds(130, 120, 180, 30);
        add(btnCust);
        
        btnStaff = new JButton ("STAFF");
        btnStaff.setBackground(Color.GREEN); // Set background color
        btnStaff.setBounds(130, 180, 180, 30);
        add(btnStaff);
        
        btnClose = new JButton ("CLOSE");
        btnClose.setBackground(Color.GREEN); // Set background color
        btnClose.setBounds(340, 265, 80, 30);
        add(btnClose);
        
        setSize(450, 340);
        setVisible(true);
        
        btnClose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to leave this page ?", "Confirm Deletion",
                        JOptionPane.YES_NO_OPTION);
                if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
                System.exit(0);
            }
        });
        
        btnCust.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginForm();
                dispose();
            }
        });
            
        btnStaff.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new StaffLogin();
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        IPTProject lab = new IPTProject();
    }
}
