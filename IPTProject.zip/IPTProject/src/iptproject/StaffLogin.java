package iptproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StaffLogin  extends JFrame{
    JLabel lblTitle, lblUser, lblPass, lblRegister;
    JTextField txtUser;
    JPasswordField pfPass;
    JButton btnLogin, btnBack;
    
    String driver = "com.mysql.cj.jdbc.Driver";
    String user = "root";
    String pass = "";
    String url = "jdbc:mysql://localhost:3306/iptproject";
    
    StaffLogin() {
        setLayout(null);
        setTitle("STAFF LOGIN PAGE");
        lblTitle = new JLabel(":: STAFF LOGIN::");
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 18));
        getContentPane().setBackground(new Color(236, 220, 252));
        lblTitle.setBounds(130, 10, 200, 30);
        add(lblTitle);
        
        lblUser = new JLabel("USERNAME");
        lblUser.setBounds(30, 60, 100, 30);
        add(lblUser);
        
        txtUser = new JTextField(20);
        txtUser.setBounds(130, 70, 250, 20);
        add(txtUser);
        
        lblPass = new JLabel("PASSWORD");
        lblPass.setBounds(30, 100, 100, 30);
        add(lblPass);
        
        pfPass = new JPasswordField(20);
        pfPass.setBounds(130, 110, 250, 20);
        add(pfPass);
        
        btnLogin = new JButton ("LOGIN");
        btnLogin.setBounds(150, 160, 110, 30);
        add(btnLogin);
        
        btnBack = new JButton ("BACK");
        btnBack.setBounds(20, 240, 100, 30);
        add(btnBack);
        
        setSize(450, 320);
        setVisible(true);
        
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = txtUser.getText();
                String password = new String(pfPass.getPassword());
                // Check if either username or password field is empty
                if (username.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please enter username and password to login");
                    return; // Exit the method
                }
                if (validateUser(username, password)) {
                    JOptionPane.showMessageDialog(null, "Login Successful");
                    new MainMenu();
                    dispose(); // Close the login form
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username and password!");
                    // Clear the text fields
                    txtUser.setText("");
                    pfPass.setText("");
                }
            }
        });
        
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new IPTProject();
                dispose(); // Close the current window
            }
        });
    }

    private boolean validateUser(String username, String password) {
        try {
            // Establish connection
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);

            // Prepare statement to check username and password
            String query = "SELECT * FROM staff WHERE username = ? AND password = ?";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setString(1, username);
            statement.setString(2, password);

            ResultSet resultSet = statement.executeQuery();
            boolean isValid = resultSet.next();

            resultSet.close();
            statement.close();
            con.close();
            return isValid;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public static void main(String[] args) {
        StaffLogin lab = new StaffLogin();
    }
}