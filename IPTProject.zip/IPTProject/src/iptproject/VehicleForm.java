package iptproject;

import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class VehicleForm extends JFrame{
    JLabel lblTitle, lblType, lblBrand, lblModel, lblNumber, lblEngine, lblColor, lblHour, lblDaily, lblWeek, lblBack;
    JTextField txtNumber, txtEngine, txtHour, txtDaily, txtWeek;
    JComboBox<String> cbType, cbBrand, cbModel, cbColor;
    
    String Type[] = {"-Select-", "Van", "Car"};
    
    String Van[] = {"-Select-", "Toyota", "Foton", "Daihatsu"};
    String Car[] = {"-Select-", "Toyota", "Proton", "Perodua", "Honda", "Nissan"};
    
    String VanToyota[] = {"-Select-", "Hiace SLWB", "Hiace"};
    String VanFoton[] = {"-Select-", "View CS2", "View C2"};
    String VanDaihatsu[] = {"-Select-", "Gran Max"};
    
    String CarToyota[] = {"-Select-", "Yaris", "Vios", "Corolla Altis", "Innova", "Camry"};
    String CarProton[] = {"-Select-", "Saga", "Persona", "X70", "Iriz", "X50"};
    String CarPerodua[] = {"-Select-", "Axia", "Myvi", "Bezza", "Ativa"};
    String CarHonda[] = {"-Select-", "Civic", "City", "CRV", "HRV"};
    String CarNissan[] = {"-Select-", "Almera", "Serena", "Grand Livina", "X-Trail"};
    
    String Color[] = {"-Select-", "Maroon", "Silver", "Red", "Blue", "White", "Black"};
    
    JButton btnAdd, btnUpdate, btnDelete, btnView, btnBack;
    JTable table;
    DefaultTableModel tableModel;
    
    String driver = "com.mysql.cj.jdbc.Driver";
    String user = "root";
    String pass = "";
    String url = "jdbc:mysql://localhost:3306/iptproject";
    
    VehicleForm () {
        setLayout(null);
        setTitle("VEHICLE PAGE");
        
        lblTitle = new JLabel("::VEHICLES::");
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 18));
        getContentPane().setBackground(new Color(236, 189, 252));
        lblTitle.setBounds(200, 10, 150, 30);
        add(lblTitle);
        
        lblType = new JLabel ("Vehicle Type :");
        lblType.setBounds(40, 40, 100, 40);
        add(lblType);
        
        cbType = new JComboBox<>(Type);
        cbType.setBounds(150, 50, 300, 25);
        add(cbType);
        
        lblBrand = new JLabel ("Brand :");
        lblBrand.setBounds(40, 80, 100, 40);
        add(lblBrand);
        
        cbBrand = new JComboBox<>();
        cbBrand.setBounds(150, 90, 300, 25);
        add(cbBrand);
        
        lblModel = new JLabel ("Model :");
        lblModel.setBounds(40, 120, 100, 40);
        add(lblModel);
        
        cbModel = new JComboBox<>();
        cbModel.setBounds(150, 130, 300, 25);
        add(cbModel);
        
        lblNumber = new JLabel ("Vehicle Number :");
        lblNumber.setBounds(40, 160, 100, 40);
        add(lblNumber);
        
        txtNumber = new JTextField(20);
        txtNumber.setBounds(150, 170, 300, 25);
        add(txtNumber);
        
        lblEngine = new JLabel ("Engine cc :");
        lblEngine.setBounds(40, 200, 100, 40);
        add(lblEngine);
        
        txtEngine = new JTextField (20);
        txtEngine.setBounds(150, 210, 300, 25);
        add(txtEngine);
        
        lblColor = new JLabel ("Color");
        lblColor.setBounds(40, 240, 100, 40);
        add(lblColor);
        
        cbColor = new JComboBox<>(Color);
        cbColor.setBounds(150, 250, 300, 25);
        add(cbColor);
        
        lblHour = new JLabel ("Price Per Hour :");
        lblHour.setBounds(40, 280, 100, 40);
        add(lblHour);
        
        txtHour = new JTextField (20);
        txtHour.setBounds(150, 290, 300, 25);
        add(txtHour);
        
        lblDaily = new JLabel ("Price Daily :");
        lblDaily.setBounds(40, 320, 100, 40);
        add(lblDaily);
        
        txtDaily = new JTextField (20);
        txtDaily.setBounds(150, 330, 300, 25);
        add(txtDaily);
        
        lblWeek = new JLabel ("Price Weekly :");
        lblWeek.setBounds(40, 360, 100, 40);
        add(lblWeek);
        
        txtWeek = new JTextField (20);
        txtWeek.setBounds(150, 370, 300, 25);
        add(txtWeek);
        
        btnAdd = new JButton ("Add");
        btnAdd.setBounds(40, 420, 100, 30);
        add(btnAdd);
        
        btnView = new JButton ("View");
        btnView.setBounds(160, 420, 100, 30);
        add(btnView);
        
        btnUpdate = new JButton ("Update");
        btnUpdate.setBounds(280, 420, 100, 30);
        add(btnUpdate);
        
        btnDelete = new JButton ("Delete");
        btnDelete.setBounds(400, 420, 100, 30);
        add(btnDelete);
        
        lblBack = new JLabel (" *click BACK button to go MAIN page ");
        lblBack.setBounds(150, 700, 300, 30);
        add(lblBack);
        
        btnBack = new JButton ("Back");
        btnBack.setBounds(400, 700, 100, 30);
        add(btnBack);
                
        cbType.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                BrandComboBox();
            }
        });

        cbBrand.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ModelComboBox();
            }
        });
        
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addVehicle();
            }
        });
        
        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateVehicle();
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteVehicle();
            }
        });
        
        btnView.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                DisplayVehicles();
            }
        });
        
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MainMenu();
                dispose(); // Close the current window
            }
        });

        // Setup table
        tableModel = new DefaultTableModel(new String[]{"Type", "Brand", "Model", "Number", "Engine", "Color", "Hour", "Daily", "Weekly"}, 0);
        table = new JTable(tableModel){
        public boolean isCellEditable(int row, int column) {
        return false; // Disable editing of cells
    }
        };
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(40, 470, 700, 200);
        add(scrollPane);
        
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    populateFieldsFromTable(selectedRow);
                }
            }
        });

        setSize(780, 780);
        setVisible(true);
    }

    private void BrandComboBox() {
        cbBrand.removeAllItems();
        cbBrand.addItem("-Select-");

        String selectedType = (String) cbType.getSelectedItem();
        if ("Van".equals(selectedType)) {
            for (String brand : Van) {
                cbBrand.addItem(brand);
            }
        } else if ("Car".equals(selectedType)) {
            for (String brand : Car) {
                cbBrand.addItem(brand);
            }
        }
    }

    private void ModelComboBox() {
        cbModel.removeAllItems();
        cbModel.addItem("-Select-");

        String selectedBrand = (String) cbBrand.getSelectedItem();
        String selectedType = (String) cbType.getSelectedItem();

        if ("Van".equals(selectedType)) {
            switch (selectedBrand) {
                case "Toyota":
                    for (String model : VanToyota) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Foton":
                    for (String model : VanFoton) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Daihatsu":
                    for (String model : VanDaihatsu) {
                        cbModel.addItem(model);
                    }
                    break;
            }
        } else if ("Car".equals(selectedType)) {
            switch (selectedBrand) {
                case "Toyota":
                    for (String model : CarToyota) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Proton":
                    for (String model : CarProton) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Perodua":
                    for (String model : CarPerodua) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Honda":
                    for (String model : CarHonda) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Nissan":
                    for (String model : CarNissan) {
                        cbModel.addItem(model);
                    }
                    break;
            }
        }
    }
    
    private void addVehicle() {
        String type = (String) cbType.getSelectedItem();
        String brand = (String) cbBrand.getSelectedItem();
        String model = (String) cbModel.getSelectedItem();
        String number = txtNumber.getText();
        String engine = txtEngine.getText();
        String color = (String) cbColor.getSelectedItem();
        String hour = txtHour.getText();
        String daily = txtDaily.getText();
        String week = txtWeek.getText();

        if (type.equals("-Select-") || brand.equals("-Select-") || model.equals("-Select-") || number.isEmpty() ||
                engine.isEmpty() || color.equals("-Select-") || hour.isEmpty() || daily.isEmpty() || week.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill in all fields and make selections from all dropdowns.");
            return;
        }

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String sql = "INSERT INTO vehicles(type, brand, model, vehicle_number, engine_cc, color, price_per_hour, price_daily, price_weekly) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement stat = con.prepareStatement(sql);
            stat.setString(1, type);
            stat.setString(2, brand);
            stat.setString(3, model);
            stat.setString(4, number);
            stat.setString(5, engine);
            stat.setString(6, color);
            stat.setString(7, hour);
            stat.setString(8, daily);
            stat.setString(9, week);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Vehicle added successfully.");
            stat.close();
            con.close();
        // Clear the fields after successful insertion
            clearFields();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        cbType.setSelectedIndex(0);
        cbBrand.removeAllItems();
        cbModel.removeAllItems();
        txtNumber.setText("");
        txtEngine.setText("");
        cbColor.setSelectedIndex(0);
        txtHour.setText("");
        txtDaily.setText("");
        txtWeek.setText("");
    }
    
    private void DisplayVehicles() {
        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM vehicles";
            Statement stat = con.createStatement();
            ResultSet res = stat.executeQuery(sql);

            tableModel.setRowCount(0); // Clear existing data

            while (res.next()) {
                String type = res.getString("type");
                String brand = res.getString("brand");
                String model = res.getString("model");
                String number = res.getString("vehicle_number");
                String engine = res.getString("engine_cc");
                String color = res.getString("color");
                String hour = res.getString("price_per_hour");
                String daily = res.getString("price_daily");
                String week = res.getString("price_weekly");
                tableModel.addRow(new Object[]{type, brand, model, number, engine, color, hour, daily, week});
            }

            res.close();
            stat.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }
    
    private void updateVehicle() {
        String type = (String) cbType.getSelectedItem();
        String brand = (String) cbBrand.getSelectedItem();
        String model = (String) cbModel.getSelectedItem();
        String number = txtNumber.getText();
        String engine = txtEngine.getText();
        String color = (String) cbColor.getSelectedItem();
        String hour = txtHour.getText();
        String daily = txtDaily.getText();
        String week = txtWeek.getText();

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String sql = "UPDATE vehicles SET type=?, brand=?, model=?, engine_cc=?, color=?, price_per_hour=?, price_daily=?, price_weekly=? WHERE vehicle_number=?";
            PreparedStatement stat = con.prepareStatement(sql);
            stat.setString(1, type);
            stat.setString(2, brand);
            stat.setString(3, model);
            stat.setString(4, engine);
            stat.setString(5, color);
            stat.setString(6, hour);
            stat.setString(7, daily);
            stat.setString(8, week);
            stat.setString(9, number);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Vehicle updated successfully.");
            stat.close();
            con.close();

            // Clear the fields after successful update
            clearFields();
            fetchAndDisplayVehicles(); // Refresh the table to show the updated vehicle
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    private void deleteVehicle() {
        String number = txtNumber.getText();

        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this vehicle?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String sql = "DELETE FROM vehicles WHERE vehicle_number=?";
            PreparedStatement stat = con.prepareStatement(sql);
            stat.setString(1, number);
            stat.executeUpdate();
            JOptionPane.showMessageDialog(null, "Vehicle deleted successfully.");
            stat.close();
            con.close();

            // Clear the fields after successful deletion
            clearFields();
            fetchAndDisplayVehicles(); // Refresh the table to show the remaining vehicles
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    private void clear() {
        cbType.setSelectedIndex(0);
        cbBrand.removeAllItems();
        cbModel.removeAllItems();
        txtNumber.setText("");
        txtEngine.setText("");
        cbColor.setSelectedIndex(0);
        txtHour.setText("");
        txtDaily.setText("");
        txtWeek.setText("");
    }

    private void populateFieldsFromTable(int selectedRow) {
        cbType.setSelectedItem(tableModel.getValueAt(selectedRow, 0).toString());
        cbBrand.setSelectedItem(tableModel.getValueAt(selectedRow, 1).toString());
        cbModel.setSelectedItem(tableModel.getValueAt(selectedRow, 2).toString());
        txtNumber.setText(tableModel.getValueAt(selectedRow, 3).toString());
        txtEngine.setText(tableModel.getValueAt(selectedRow, 4).toString());
        cbColor.setSelectedItem(tableModel.getValueAt(selectedRow, 5).toString());
        txtHour.setText(tableModel.getValueAt(selectedRow, 6).toString());
        txtDaily.setText(tableModel.getValueAt(selectedRow, 7).toString());
        txtWeek.setText(tableModel.getValueAt(selectedRow, 8).toString());
    }

    private void fetchAndDisplayVehicles() {
        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String sql = "SELECT * FROM vehicles";
            Statement stat = con.createStatement();
            ResultSet res = stat.executeQuery(sql);

            tableModel.setRowCount(0); // Clear existing data

            while (res.next()) {
                String type = res.getString("type");
                String brand = res.getString("brand");
                String model = res.getString("model");
                String number = res.getString("vehicle_number");
                String engine = res.getString("engine_cc");
                String color = res.getString("color");
                String hour = res.getString("price_per_hour");
                String daily = res.getString("price_daily");
                String week = res.getString("price_weekly");
                tableModel.addRow(new Object[]{type, brand, model, number, engine, color, hour, daily, week});
            }

            res.close();
            stat.close();
            con.close();
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        VehicleForm lab = new VehicleForm();
    }
}