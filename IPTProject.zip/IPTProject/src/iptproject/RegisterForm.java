package iptproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RegisterForm extends JFrame{
    JLabel lblTitle, lblUser, lblPass, lblPhone, lblEmail;
    JTextField txtUser, txtPhone, txtEmail;
    JPasswordField pfPass;
    JButton btnRegister;
    
    String driver = "com.mysql.cj.jdbc.Driver";
    String user = "root";
    String pass = "";
    String url = "jdbc:mysql://localhost:3306/iptproject";
    
    RegisterForm() {
        setLayout(null);
        setTitle("REGISTER PAGE");
        lblTitle = new JLabel("::REGISTER::");
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 18));
        lblTitle.setBounds(170, 10, 200, 30);
        getContentPane().setBackground(new Color(236, 220, 252));
        add(lblTitle);
        
        lblUser = new JLabel("USERNAME");
        lblUser.setBounds(40, 60, 100, 30);
        add(lblUser);
        
        txtUser = new JTextField(20);
        txtUser.setBounds(180, 70, 250, 20);
        add(txtUser);
        
        lblPass = new JLabel("PASSWORD");
        lblPass.setBounds(40, 100, 100, 30);
        add(lblPass);
        
        pfPass = new JPasswordField(20);
        pfPass.setBounds(180, 110, 250, 20);
        add(pfPass);
        
        lblPhone = new JLabel("CONTACT NUMBER");
        lblPhone.setBounds(40, 140, 200, 30);
        add(lblPhone);
        
        txtPhone = new JTextField(20);
        txtPhone.setBounds(180, 150, 250, 20);
        add(txtPhone);
        
        lblEmail = new JLabel("EMAIL ADDRESS");
        lblEmail.setBounds(40, 180, 100, 30);
        add(lblEmail);
        
        txtEmail = new JTextField(20);
        txtEmail.setBounds(180, 190, 250, 20);
        add(txtEmail);
        
        btnRegister = new JButton ("REGISTER");
        btnRegister.setBounds(180, 250, 110, 30);
        add(btnRegister);
        
        setSize(500, 400);
        setVisible(true);
        
            btnRegister.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = txtUser.getText();
                String password = new String(pfPass.getPassword());
                String contact = txtPhone.getText();
                String email = txtEmail.getText();
                
                if (username.isEmpty() || password.isEmpty() || contact.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Please fill up all fields to register!!");
                    return; // Exit the method
                }
                if (registerUser(username, password, contact, email)) {
                    JOptionPane.showMessageDialog(null, "Registration Successful");
                    new IPTProject();
                    // Assuming you have a LoginForm class
                    // new LoginForm().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Registration Failed");
                }
            }
        });
    }
    
    private boolean registerUser(String username, String password, String contact, String email) {
        try {
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(url, user, pass);
            String query = "INSERT INTO register (Username, Password, Contact, Email) VALUES (?, ?, ?, ?)";
            PreparedStatement stat = conn.prepareStatement(query);
            stat.setString(1, username);
            stat.setString(2, password);
            stat.setString(3, contact);
            stat.setString(4, email);
            stat.executeUpdate();
            stat.close();
            conn.close();
            return true;
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            return false;
        }
    }

    public static void main(String[] args) {
        RegisterForm lab = new RegisterForm();
    }
}