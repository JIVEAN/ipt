package iptproject;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainMenu extends JFrame{
    JLabel lblTitle, lblTajuk;
    JButton btnCust, btnVehicle, btnClose;
    
    MainMenu(){
        setLayout(null);
        setTitle("MAIN MENU");
        
        lblTitle = new JLabel("::MAIN MENU::");
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 18));
        lblTitle.setBounds(150, 10, 200, 30);
        add(lblTitle);
        
        lblTajuk = new JLabel("IZZAH CAR RENTAL SYSTEM");
        lblTajuk.setForeground(Color.BLUE);
        lblTajuk.setFont(new Font("VERDANA",Font.BOLD, 21));
        getContentPane().setBackground(new Color(236, 220, 252));
        lblTajuk.setBounds(55, 40, 500, 30);
        add(lblTajuk);
        
        btnCust = new JButton ("CUSTOMER DETAILS");
        btnCust.setBackground(Color.GREEN); // Set background color
        btnCust.setBounds(130, 120, 180, 30);
        add(btnCust);
        
        btnVehicle = new JButton ("VEHICLE DETAILS");
        btnVehicle.setBackground(Color.GREEN); // Set background color
        btnVehicle.setBounds(130, 180, 180, 30);
        add(btnVehicle);
        
        btnClose = new JButton ("CLOSE");
        btnClose.setBackground(Color.GREEN); // Set background color
        btnClose.setBounds(340, 265, 80, 30);
        add(btnClose);
        
        setSize(450, 340);
        setVisible(true);
        
        btnClose.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
            int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to leave this page ?", "Confirm Deletion",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
                System.exit(0);
                
            }
        });
        
        btnCust.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new CustomerForm();
                dispose();
            }
        });
            
        btnVehicle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new VehicleForm();
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        MainMenu lab = new MainMenu();
    }
}
