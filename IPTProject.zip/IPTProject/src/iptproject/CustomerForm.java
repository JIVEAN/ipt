package iptproject;

import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class CustomerForm extends JFrame{
    JLabel lblTitle, lblID, lblName, lblPhone, lblIC, lblType, lblBrand, lblModel, lblHour, lblDaily, lblWeek, lblTotal, lblBack;
    JTextField txtID, txtName, txtPhone, txtIC, txtHour, txtDaily, txtWeek, txtTotal;
    JComboBox<String> cbType, cbBrand, cbModel;
    
    String Type[] = {"-Select-", "Van", "Car"};
    
    String Van[] = {"-Select-", "Toyota", "Foton", "Daihatsu"};
    String Car[] = {"-Select-", "Toyota", "Proton", "Perodua", "Honda", "Nissan"};
    
    String VanToyota[] = {"-Select-", "Hiace SLWB", "Hiace"};
    String VanFoton[] = {"-Select-", "View CS2", "View C2"};
    String VanDaihatsu[] = {"-Select-", "Gran Max"};
    
    String CarToyota[] = {"-Select-", "Yaris", "Vios", "Corolla Altis", "Innova", "Camry"};
    String CarProton[] = {"-Select-", "Saga", "Persona", "X70", "Iriz", "X50"};
    String CarPerodua[] = {"-Select-", "Axia", "Myvi", "Bezza", "Ativa"};
    String CarHonda[] = {"-Select-", "Civic", "City", "CRV", "HRV"};
    String CarNissan[] = {"-Select-", "Almera", "Serena", "Grand Livina", "X-Trail"};
    
    JButton btnAdd, btnUpdate, btnDelete, btnView, btnSearch, btnTotal, btnBack, btnClear;
    JTable table;
    DefaultTableModel tableModel;
    
    String driver = "com.mysql.cj.jdbc.Driver";
    String user = "root";
    String pass = "";
    String url = "jdbc:mysql://localhost:3306/iptproject";
    
    CustomerForm() {
        setLayout(null);
        setTitle("CUSTOMER PAGE");
        
        lblTitle = new JLabel("::CUSTOMERS::");
        lblTitle.setFont(new Font("VERDANA", Font.BOLD, 18));
        getContentPane().setBackground(new Color(236, 189, 252));
        lblTitle.setBounds(200, 10, 200, 30);
        add(lblTitle);
        
        lblID = new JLabel ("Customer ID :");
        lblID.setBounds(40, 40, 100, 40);
        add(lblID);
        
        txtID = new JTextField (20);
        txtID.setBounds(150, 50, 300, 25);
        add(txtID);
        
        btnSearch = new JButton ("Search");
        btnSearch.setBounds(460, 50, 100, 25);
        add(btnSearch);
        
        btnClear = new JButton ("Clear");
        btnClear.setBounds(460, 90, 100, 25);
        add(btnClear);
        
        lblName = new JLabel ("Name :");
        lblName.setBounds(40, 80, 100, 40);
        add(lblName);
        
        txtName = new JTextField (20);
        txtName.setBounds(150, 90, 300, 25);
        add(txtName);
        
        lblPhone = new JLabel ("Contact Number :");
        lblPhone.setBounds(40, 120, 100, 40);
        add(lblPhone);
        
        txtPhone = new JTextField (20);
        txtPhone.setBounds(150, 130, 300, 25);
        add(txtPhone);
        
        lblIC = new JLabel ("IC Number :");
        lblIC.setBounds(40, 160, 100, 40);
        add(lblIC);
        
        txtIC = new JTextField(20);
        txtIC.setBounds(150, 170, 300, 25);
        add(txtIC);
        
        lblType = new JLabel ("Vehicle Type :");
        lblType.setBounds(40, 200, 100, 40);
        add(lblType);
        
        cbType = new JComboBox<>(Type);
        cbType.setBounds(150, 210, 300, 25);
        add(cbType);
        
        lblBrand = new JLabel ("Brand :");
        lblBrand.setBounds(40, 240, 100, 40);
        add(lblBrand);
        
        cbBrand = new JComboBox<>();
        cbBrand.setBounds(150, 250, 300, 25);
        add(cbBrand);
        
        lblModel = new JLabel ("Model :");
        lblModel.setBounds(40, 280, 100, 40);
        add(lblModel);
        
        cbModel = new JComboBox<>();
        cbModel.setBounds(150, 290, 300, 25);
        add(cbModel);
        
        lblHour = new JLabel ("Hours :");
        lblHour.setBounds(40, 320, 100, 40);
        add(lblHour);
        
        txtHour = new JTextField (20);
        txtHour.setBounds(150, 330, 300, 25);
        add(txtHour);
        
        lblDaily = new JLabel ("Days :");
        lblDaily.setBounds(40, 360, 100, 40);
        add(lblDaily);
        
        txtDaily = new JTextField (20);
        txtDaily.setBounds(150, 370, 300, 25);
        add(txtDaily);
        
        lblWeek = new JLabel ("Weeks :");
        lblWeek.setBounds(40, 400, 100, 40);
        add(lblWeek);
        
        txtWeek = new JTextField (20);
        txtWeek.setBounds(150, 410, 300, 25);
        add(txtWeek);
        
        lblTotal = new JLabel ("Total Price :");
        lblTotal.setBounds(40, 440, 100, 40);
        add(lblTotal);
        
        txtTotal = new JTextField (20);
        txtTotal.setBounds(150, 450, 170, 25);
        add(txtTotal);
        
        btnTotal = new JButton ("Total");
        btnTotal.setBounds(350, 450, 100, 25);
        add(btnTotal);
        
        txtTotal.setEditable(false);
        
        btnAdd = new JButton ("Add");
        btnAdd.setBounds(40, 500, 100, 30);
        add(btnAdd);
        
        btnView = new JButton ("View");
        btnView.setBounds(160, 500, 100, 30);
        add(btnView);
        
        btnUpdate = new JButton ("Update");
        btnUpdate.setBounds(280, 500, 100, 30);
        add(btnUpdate);
        
        btnDelete = new JButton ("Delete");
        btnDelete.setBounds(400, 500, 100, 30);
        add(btnDelete);
        
        lblBack = new JLabel (" *click BACK button to go MAIN page ");
        lblBack.setForeground(Color.RED);
        lblBack.setBounds(150, 745, 300, 30);
        add(lblBack);
        
        
        btnBack = new JButton ("Back");
        btnBack.setBounds(400, 745, 100, 30);
        add(btnBack);
        
        cbType.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                BrandComboBox();
            }
        });

        cbBrand.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ModelComboBox();
            }
        });
        
       btnTotal.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        String hoursStr = txtHour.getText();
        String daysStr = txtDaily.getText();
        String weeksStr = txtWeek.getText();

        try {
            double hours = hoursStr.isEmpty() ? 0 : Double.parseDouble(hoursStr);
            double days = daysStr.isEmpty() ? 0 : Double.parseDouble(daysStr);
            double weeks = weeksStr.isEmpty() ? 0 : Double.parseDouble(weeksStr);

            // Get the price per hour, day, and week from the database based on the selected vehicle type, brand, and model
            double price_per_hour = getPricePerHourFromDatabase();
            double price_daily = getPriceDailyFromDatabase();
            double price_weekly = getPriceWeeklyFromDatabase();

            double totalPrice = 0;

            if (hours > 0) {
            totalPrice += hours * price_per_hour;
            } if (days > 0) {
            totalPrice += days * price_daily;
            } if (weeks > 0) {
            totalPrice += weeks * price_weekly;
            }

      
            
        // Display the total price in the txtTotal field
        txtTotal.setText("RM "+String.valueOf(totalPrice));
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(CustomerForm.this, "Invalid input for hours, days, or weeks!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(CustomerForm.this, "Error fetching prices from the database: " + ex.getMessage());
        }
    }
});
 
        btnAdd.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                addCustomer();
            }
        });
        
        btnView.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadData();
            }
        });

        btnUpdate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateCustomer();
            }
        });

        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteCustomer();
            }
        });

        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new MainMenu().setVisible(true);
                dispose();
            }
        });
        
        
        
        btnSearch.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        String customerID = JOptionPane.showInputDialog("Enter Customer ID:");
        if (customerID != null && !customerID.isEmpty()) {
            searchCustomer(customerID);
        } else {
            JOptionPane.showMessageDialog(CustomerForm.this, "Please enter a valid Customer ID!");
        }
    }
});
        
        btnClear.addActionListener(new ActionListener() {
    public void actionPerformed(ActionEvent e) {
        clearFields();
    }
});
        
        setSize(900, 830);
        setVisible(true);
        
        // Initialize JTable
        initializeTable();
    }
    
    private void initializeTable() {
        tableModel = new DefaultTableModel();
        table = new JTable(tableModel);

        // Add columns to the table model
        tableModel.addColumn("Customer ID");
        tableModel.addColumn("Name");
        tableModel.addColumn("Contact Number");
        tableModel.addColumn("IC Number");
        tableModel.addColumn("Vehicle Type");
        tableModel.addColumn("Brand");
        tableModel.addColumn("Model");
        tableModel.addColumn("Hours");
        tableModel.addColumn("Days");
        tableModel.addColumn("Weeks");
        tableModel.addColumn("Total Price");

        // Set JTable properties
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(40, 540, 820, 200);
        add(scrollPane);

        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    txtID.setText(tableModel.getValueAt(selectedRow, 0).toString());
                    txtName.setText(tableModel.getValueAt(selectedRow, 1).toString());
                    txtPhone.setText(tableModel.getValueAt(selectedRow, 2).toString());
                    txtIC.setText(tableModel.getValueAt(selectedRow, 3).toString());
                    cbType.setSelectedItem(tableModel.getValueAt(selectedRow, 4).toString());
                    cbBrand.setSelectedItem(tableModel.getValueAt(selectedRow, 5).toString());
                    cbModel.setSelectedItem(tableModel.getValueAt(selectedRow, 6).toString());
                    txtHour.setText(tableModel.getValueAt(selectedRow, 7).toString());
                    txtDaily.setText(tableModel.getValueAt(selectedRow, 8).toString());
                    txtWeek.setText(tableModel.getValueAt(selectedRow, 9).toString());
                    txtTotal.setText(tableModel.getValueAt(selectedRow, 10).toString());
                }
            }
        });
    }

    private void BrandComboBox() {
        cbBrand.removeAllItems();
        cbBrand.addItem("-Select-");

        String selectedType = (String) cbType.getSelectedItem();
        if ("Van".equals(selectedType)) {
            for (String brand : Van) {
                cbBrand.addItem(brand);
            }
        } else if ("Car".equals(selectedType)) {
            for (String brand : Car) {
                cbBrand.addItem(brand);
            }
        }
    }

    private void ModelComboBox() {
        cbModel.removeAllItems();
        cbModel.addItem("-Select-");

        String selectedBrand = (String) cbBrand.getSelectedItem();
        String selectedType = (String) cbType.getSelectedItem();

        if ("Van".equals(selectedType)) {
            switch (selectedBrand) {
                case "Toyota":
                    for (String model : VanToyota) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Foton":
                    for (String model : VanFoton) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Daihatsu":
                    for (String model : VanDaihatsu) {
                        cbModel.addItem(model);
                    }
                    break;
            }
        } else if ("Car".equals(selectedType)) {
            switch (selectedBrand) {
                case "Toyota":
                    for (String model : CarToyota) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Proton":
                    for (String model : CarProton) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Perodua":
                    for (String model : CarPerodua) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Honda":
                    for (String model : CarHonda) {
                        cbModel.addItem(model);
                    }
                    break;
                case "Nissan":
                    for (String model : CarNissan) {
                        cbModel.addItem(model);
                    }
                    break;
            }
        }
    }

    private void addCustomer() {
        String custID = txtID.getText();
        String custName = txtName.getText();
        String custPhone = txtPhone.getText();
        String custIC = txtIC.getText();
        String type = (String) cbType.getSelectedItem();
        String brand = (String) cbBrand.getSelectedItem();
        String model = (String) cbModel.getSelectedItem();
        String hours = txtHour.getText();
        String days = txtDaily.getText();
        String weeks = txtWeek.getText();
        String total = txtTotal.getText();

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String query = "INSERT INTO customers (cust_id, cust_name, cust_tel, cust_ic, type, brand, model, hour, day, week, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, custID);
            pst.setString(2, custName);
            pst.setString(3, custPhone);
            pst.setString(4, custIC);
            pst.setString(5, type);
            pst.setString(6, brand);
            pst.setString(7, model);
            pst.setString(8, hours);
            pst.setString(9, days);
            pst.setString(10, weeks);
            pst.setString(11, total);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Customer added successfully!");
            clearFields();
            pst.close();
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void updateCustomer() {
        String custID = txtID.getText();
        String custName = txtName.getText();
        String custPhone = txtPhone.getText();
        String custIC = txtIC.getText();
        String type = (String) cbType.getSelectedItem();
        String brand = (String) cbBrand.getSelectedItem();
        String model = (String) cbModel.getSelectedItem();
        String hours = txtHour.getText();
        String days = txtDaily.getText();
        String weeks = txtWeek.getText();
        String total = txtTotal.getText();

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String query = "UPDATE customers SET cust_name = ?, cust_tel = ?, cust_ic = ?, type = ?, brand = ?, model = ?, hour = ?, day = ?, week = ?, total = ? WHERE cust_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, custName);
            pst.setString(2, custPhone);
            pst.setString(3, custIC);
            pst.setString(4, type);
            pst.setString(5, brand);
            pst.setString(6, model);
            pst.setString(7, hours);
            pst.setString(8, days);
            pst.setString(9, weeks);
            pst.setString(10, total);
            pst.setString(11, custID);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Customer updated successfully!");
            clearFields();
            loadData();
            pst.close();
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void deleteCustomer() {
        String custID = txtID.getText();
        
        int confirm = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete ?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        

        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String query = "DELETE FROM customers WHERE cust_id = ?";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, custID);

            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Customer deleted successfully!");
            clearFields();
            loadData();
            pst.close();
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        txtID.setText("");
        txtName.setText("");
        txtPhone.setText("");
        txtIC.setText("");
        cbType.setSelectedIndex(0);
        cbBrand.removeAllItems();
        cbModel.removeAllItems();
        txtHour.setText("");
        txtDaily.setText("");
        txtWeek.setText("");
        txtTotal.setText("");
    }

    private void loadData() {
        try {
            Class.forName(driver);
            Connection con = DriverManager.getConnection(url, user, pass);
            String query = "SELECT * FROM customers";
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            tableModel.setRowCount(0); // Clear existing data

            while (rs.next()) {
                String custID = rs.getString("cust_id");
                String custName = rs.getString("cust_name");
                String custPhone = rs.getString("cust_tel");
                String custIC = rs.getString("cust_ic");
                String type = rs.getString("type");
                String brand = rs.getString("brand");
                String model = rs.getString("model");
                String hours = rs.getString("hour");
                String days = rs.getString("day");
                String weeks = rs.getString("week");
                String total = rs.getString("total");

                tableModel.addRow(new Object[]{custID, custName, custPhone, custIC, type, brand, model, hours, days, weeks, total});
            }

            rs.close();
            pst.close();
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }
    
    private void searchCustomer(String customerID) {
    try {
        Class.forName(driver);
        Connection con = DriverManager.getConnection(url, user, pass);
        String query = "SELECT * FROM customers WHERE cust_id = ?";
        PreparedStatement pst = con.prepareStatement(query);
        pst.setString(1, customerID);
        ResultSet rs = pst.executeQuery();

        if (rs.next()) {
            // Customer found, populate fields
            txtID.setText(rs.getString("cust_id"));
            txtName.setText(rs.getString("cust_name"));
            txtPhone.setText(rs.getString("cust_tel"));
            txtIC.setText(rs.getString("cust_ic"));
            cbType.setSelectedItem(rs.getString("type"));
            cbBrand.setSelectedItem(rs.getString("brand"));
            cbModel.setSelectedItem(rs.getString("model"));
            txtHour.setText(rs.getString("hour"));
            txtDaily.setText(rs.getString("day"));
            txtWeek.setText(rs.getString("week"));
            txtTotal.setText(rs.getString("total"));
        } else {
            JOptionPane.showMessageDialog(this, "No customer found with ID: " + customerID);
        }

        rs.close();
        pst.close();
        con.close();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}

            
    private double getPricePerHourFromDatabase() throws SQLException {
    double price = 0;
    String selectedType = (String) cbType.getSelectedItem();
    String selectedBrand = (String) cbBrand.getSelectedItem();
    String selectedModel = (String) cbModel.getSelectedItem();
    
    try (Connection connection = DriverManager.getConnection(url, user, pass)) {
        String query = "SELECT price_per_hour FROM vehicles WHERE type = ? AND brand = ? AND model = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, selectedType);
            statement.setString(2, selectedBrand);
            statement.setString(3, selectedModel);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    price = resultSet.getDouble("price_per_hour");
                }
            }
        }
    } catch (SQLException ex) {
        // Handle database query exception
        throw ex;
    }
    
    return price;
}

// Implement getPricePerDayFromDatabase() and getPricePerWeekFromDatabase() similarly

private double getPriceDailyFromDatabase() throws SQLException {
    double price = 0;
    String selectedType = (String) cbType.getSelectedItem();
    String selectedBrand = (String) cbBrand.getSelectedItem();
    String selectedModel = (String) cbModel.getSelectedItem();
    
    try (Connection connection = DriverManager.getConnection(url, user, pass)) {
        String query = "SELECT price_daily FROM vehicles WHERE type = ? AND brand = ? AND model = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, selectedType);
            statement.setString(2, selectedBrand);
            statement.setString(3, selectedModel);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    price = resultSet.getDouble("price_daily");
                }
            }
        }
    } catch (SQLException ex) {
        // Handle database query exception
        throw ex;
    }
    
    return price;
}

private double getPriceWeeklyFromDatabase() throws SQLException {
    double price = 0;
    String selectedType = (String) cbType.getSelectedItem();
    String selectedBrand = (String) cbBrand.getSelectedItem();
    String selectedModel = (String) cbModel.getSelectedItem();
    
    try (Connection connection = DriverManager.getConnection(url, user, pass)) {
        String query = "SELECT price_weekly FROM vehicles WHERE type = ? AND brand = ? AND model = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, selectedType);
            statement.setString(2, selectedBrand);
            statement.setString(3, selectedModel);
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    price = resultSet.getDouble("price_weekly");
                }
            }
        }
    } catch (SQLException ex) {
        // Handle database query exception
        throw ex;
    }
    
    return price;
} 
     
    
    
    
    public static void main(String[] args) {
        CustomerForm lab = new CustomerForm();
    }
}